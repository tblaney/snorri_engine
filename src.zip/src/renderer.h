#pragma once

#include "shader.h"
#include "computesurface.h"
#include "camera/camera.h"
#include "light.h"
#include "object/point.h"
#include "object/object.h"

class Renderer : public Component {
private:
    unsigned int VAO, VBO, EBO;
    unsigned int texture;
    unsigned int textureUi;
    Shader shader;
    ComputeShaderSurface compute;
    float outlineWidth;
    int width;
    int height;

public:
    Renderer(Object* parent);
    ~Renderer() override;

    void loadFromJson(const nlohmann::json& json) override;
    void updateRender() override;

    void createSolidColorTexture(unsigned int& texture, int width, int height, const glm::vec3& color);
    void setupSurfaceBuffer();
    void setupComputeData(Camera* camera, Light* light);
    void render(Camera* camera, Light* light);
};