#include "window.h"
#include "shader.h"
#include "renderer.h"

#include "file/pathutils.h"
#include "file/jsonloader.h"

#include "object/object.h"
#include "object/point.h"

#include "camera/camera.h"

#include <iostream> 
#include <filesystem>
#include <nlohmann/json.hpp>
#include <vector>


void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);

    // Get the Renderer and Camera instances from the window's user pointer
    Renderer* renderer = static_cast<Renderer*>(glfwGetWindowUserPointer(window));
    Camera* camera = static_cast<Camera*>(glfwGetWindowUserPointer(window));

    // Update the aspect ratio of the camera
    float aspectRatio = static_cast<float>(width) / static_cast<float>(height);
    camera->updateAspectRatio(aspectRatio);

    // Update the vertices of the renderer
    renderer->updateVerticesBasedOnAspectRatio();
    renderer->updateVertices();
}


int main() {
    // Create a Point instance
    glm::vec3 position(0.0f, 0.0f, 3.0f);
    glm::vec3 rotation(0.0f, 0.0f, 0.0f);
    glm::vec3 scale(1.0f, 1.0f, 1.0f);
    Point cameraPosition(position, rotation, scale);

    // Create a Camera instance
    glm::vec3 startFront(0.0f, 0.0f, -1.0f);
    glm::vec3 startUp(0.0f, 1.0f, 0.0f);
    float fov = 45.0f;
    float aspectRatio = 640.0f / 360.0f;
    float nearPlane = 0.1f;
    float farPlane = 100.0f;

    Camera camera(cameraPosition, startFront, startUp, fov, aspectRatio, nearPlane, farPlane);

    // Display the Point's attributes
    std::cout << "Initial Point attributes:" << std::endl;
    std::cout << "Position: (" 
              << camera.getPoint().getPosition().x << ", "
              << camera.getPoint().getPosition().y << ", "
              << camera.getPoint().getPosition().z << ")" << std::endl;
    std::cout << "Rotation: (" 
              << camera.getPoint().getRotation().x << ", "
              << camera.getPoint().getRotation().y << ", "
              << camera.getPoint().getRotation().z << ")" << std::endl;
    std::cout << "Scale: (" 
              << camera.getPoint().getScale().x << ", "
              << camera.getPoint().getScale().y << ", "
              << camera.getPoint().getScale().z << ")" << std::endl;

    Window window(640, 360, "snorri_engine_v1");

    glfwSetWindowUserPointer(window.getGLFWwindow(), &camera);
    glfwSetFramebufferSizeCallback(window.getGLFWwindow(), framebuffer_size_callback);

    // Get the path to the executable's directory
    std::filesystem::path execPath = getExecutablePath();
    std::cerr << "Executable Path: " << execPath << std::endl;

    // Construct the paths to the shader files
    std::filesystem::path vertexPath = getAssetPath("shaders/vertex_shader.glsl");
    std::filesystem::path fragmentPath = getAssetPath("shaders/fragment_shader.glsl");

    std::filesystem::path jsonPath = getAssetPath("data/config.json");
    nlohmann::json config = JsonLoader::loadJsonFile(jsonPath);
    std::cerr << "Loaded JSON: " << config.dump(4) << std::endl;

    std::cerr << "Vertex Shader Path: " << vertexPath << std::endl;
    std::cerr << "Fragment Shader Path: " << fragmentPath << std::endl;

    Renderer renderer(camera, vertexPath.string(), fragmentPath.string());
    
    while (!window.shouldClose()) {
        window.clear();

        renderer.render();

        window.display();
        window.pollEvents();
    }

    return 0;
}
