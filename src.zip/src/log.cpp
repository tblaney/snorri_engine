// Log.cpp
#include "Log.h"
#include <iostream>

void Log::console(const std::string& logText) {
    std::cout << logText << std::endl;
}
