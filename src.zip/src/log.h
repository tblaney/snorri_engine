// Log.h
#ifndef LOG_H
#define LOG_H

#include <string>

class Log {
public:
    static void console(const std::string& logText);
};

#endif // LOG_H
