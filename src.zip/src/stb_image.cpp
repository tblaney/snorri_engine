#define STB_IMAGE_IMPLEMENTATION
#include "../external/stb/include/stb_image.h"
